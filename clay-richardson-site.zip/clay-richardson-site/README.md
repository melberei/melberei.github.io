# Clay Richardson — Portfolio (Static Site)

A static HTML/CSS replica of clayrichardson.com, built for GitHub Pages so it's
viewable behind corporate firewalls that block the live WordPress domain.

## What's here

```
index.html              Homepage
alerts-center.html      Case study — Inbox/Alerts Center
security-center.html    Case study — Security Center
trust-services.html     Case study — Trust Services
contact.html            Contact page
style.css               All styling
nav.js                  Mobile nav + dropdown behavior
images/                 Logo + placeholder thumbnails (swap these out)
```

## To-do before this is ready to share

1. **Subpage copy** — `alerts-center.html`, `security-center.html`,
   `trust-services.html`, and `contact.html` each have an HTML comment
   marking where to paste the real case study text.
2. **Images** — swap the files in `images/` (currently placeholder SVGs)
   for the real screenshots/photos from the live site. Keep the same
   filenames or update the `src` attributes in each HTML file.
3. **Contact details** — update the email and LinkedIn link in `contact.html`.

## Publishing to GitHub Pages

Since the repo is named `clay-richardson.github.io`, GitHub Pages will
serve it automatically at `https://clay-richardson.github.io/` once pushed
to the `main` branch — no extra config needed.

```bash
# from inside this folder
git init
git add .
git commit -m "Initial static portfolio"
git branch -M main
git remote add origin https://github.com/<his-username>/clay-richardson.github.io.git
git push -u origin main
```

Then in the repo's **Settings → Pages**, confirm the source is set to
`Deploy from a branch` → `main` → `/ (root)`. The site will be live in
a minute or two at `https://clay-richardson.github.io/`.

## Notes

- No build step — plain HTML/CSS/JS, works straight from GitHub Pages.
- Responsive down to mobile; nav collapses to a toggle menu under 860px.
- Skip-link and visible focus states included for accessibility.
